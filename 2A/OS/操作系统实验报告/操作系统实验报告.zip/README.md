# README

由于笔者的project1试验结果影响了project2, 因此提交了一个git仓库, 仓库内有三个分支`master` `project1` `project2` , project1为第一个项目的代码, project2为第二个项目的代码. 

## 环境

笔者使用的环境:

- manjaro linux 20
- qemu ver 5.2.0

以及强烈不建议在Projcet1使用qemu, 因为qemu的时钟系统不像bochs那样可以加速, 所以在做project1的task3的时候测试要等很长时间, 体验很差.

