#include <stdio.h>

main ()
{

   int pid;

   printf ("Original process:\n PID = %d \n PPID %d \n", getpid (), getppid ());

   // getpid ()----- getpid���ص�ǰ���̱�ʶ

   // getppid () -----getppid���ظ����̱�ʶ


   pid = fork ();   // Duplicate. Child and parent------continue 


   if (pid != 0)      // pid is non-zero ----- parent 
   {

     printf ("Parent process : PID %d , PPID %d.\n", getpid (), getppid ());

     printf ("My child's PID is %d\n", pid);

   }
   else 	/* pid is zero --- child */
   {
       printf ("Child process PID %d ;PP PID %d \n", getpid (), getppid ());
   }

  printf ("PID %d terminates.\n", getpid () ); /* Both processes execute this */

}
