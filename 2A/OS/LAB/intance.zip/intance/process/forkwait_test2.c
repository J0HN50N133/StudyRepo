# include <stdio.h>
#include <sys/types.h>   // for pid_t
int main()
{
	pid_t  pid;
	
	printf("\n\n<<<<<<<<<<<<<<<<<<<<<<<<<<<<<\n\n");

	printf ("Original process with PID %d and PPID %d.\n", getpid (), getppid ());

	printf(" ----------------fork()-------------------\n");

	/* fork another process */
	pid = fork();

	if (pid < 0)  /* error occurred */
	{	fprintf(stderr, "Fork Failed.\n");
		exit(-1);
	}

	if (pid == 0) /* child process */
	{ 
		printf ("CHILD process with PID %d and PPID %d.\n",getpid (), getppid ());

		printf("Do something in the CHILD process.\n");
	}
	else  /* parent process */
	{

		printf ("PARENT process with PID %d and PPID %d.\n",getpid (), getppid ());

		printf ("My child's PID is %d\n", pid);

		/* parent will wait for the child to complete */
		wait (NULL);
		//wait()����ʹ��������ͣ��ֱ������һ���ӽ��̽���Ϊֹ���ú����ķ���ֵ����ֹ���е��ӽ��̵�PID
		
		printf ("Child Complete.\n");
//		exit(0);
	}

	printf ("PID %d terminates.\n", getpid () ); /* Both processes execute this */
	printf("\n>>>>>>>>>>>>>>>>>>>>>>>>>>>>>\n\n");
}
