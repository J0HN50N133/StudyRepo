# Note For Nick Feamster's Course

## The Architectual Design Principles

阅读材料: 

[](https://dl.acm.org/doi/pdf/10.1145/52324.52336)

The design philosophy of the darpa internet protocols — Dave Clark 1988

> The **top level goal** for the DARPA Internet Architecture was to develop an **effective** technique for **multiplexed utilization** of existing interconnected networks. Some elaboration is appropriate to make clear the meaning of that goal.

### Technique

- Packet switching
    1. The technique selected for multiplexing.
    2. Information for forwarding traffic is contained in **destination address** of packet
    3. compare of circuit switching and packet switching: [🔗](https://www.notion.so/Introduction-780ea22c7ae447198c3c20fbc8bb1048)