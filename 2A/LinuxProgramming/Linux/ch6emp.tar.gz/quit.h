#include<stdio.h>
#include<stdlib.h>

void quit(char*, int);
