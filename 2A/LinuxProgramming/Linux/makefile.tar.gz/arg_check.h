#include<stdio.h>
#include<stdlib.h>

void arg_check(int, int, char*, int);
