#!/bin/bash

ls -l --color | sort -k 5 -nr | tr -s " " | cut -d" " -f5,9
exit

