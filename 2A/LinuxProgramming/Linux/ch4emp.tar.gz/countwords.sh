#!/bin/bash

if [ $# -eq 0 ]
then
	echo "Usage: $0 filename"; exit 1
fi

fname=$1
type=`file -b $fname`

if [[ "$type" != "ASCII text" ]]
then
	echo "$fname is not a text file"; exit 2
else
	tr " \011:" "\012\012\012" < $fname | sort | uniq -c | pr -t -5 -a
fi

exit

