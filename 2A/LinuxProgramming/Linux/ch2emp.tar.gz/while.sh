#!/bin/sh

answer=y
while [ "$answer" = "y" ]
do
	echo "Enter name and telepone number: \c" 1>&2
	read name number
	echo "$name:$number"
	echo "Any other entries (y/n)? \c" 1>&2
	read other
	case "$other" in
	y|Y) answer="y" ;;
	*) answer="n"
	esac
done >> addressbook
echo "End"
exit

