#!/bin/sh

yesorno() {
	echo "$1 (y/n): \c" 1>&2
	read response
	case "$response" in
	y|Y) return 0;;
	*) return 1
	esac
}

answer=0
until [ $(($answer)) -ne 0 ]
do
	echo "Enter name and telephone number: \c" 1>&2
	read name number
	echo "$name:$number"
	if yesorno "Any other entries?"
	then
		answer=0
	else
		answer=1
	fi
done >> addressbook
echo "Done"
exit
