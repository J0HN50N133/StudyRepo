#!/bin/bash

echo "This program is ${0##*/}"
echo "The number of arguments is $#"
echo "The list of arguments is $@"
echo "The first 3 arguments are $1, $2, $3"
shift
echo "After shift, the first 3 arguments are $1, $2, $3"
shift 3
echo "After shift 3, the first 3 arguments are $1, $2, $3"
exit

