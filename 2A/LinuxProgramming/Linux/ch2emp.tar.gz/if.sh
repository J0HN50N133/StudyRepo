#!/bin/sh
if [ -z "$*" ]
then 
	echo "No argument is given"
	exit 1
else
	echo "The argument list is $@"
fi
exit

