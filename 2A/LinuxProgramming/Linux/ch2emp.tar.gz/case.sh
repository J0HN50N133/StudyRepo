#!/bin/sh

echo "Menu
A. List of files
B. Processes of User
C. Today's date
D. User list of system
Enter your choice: \c"
read choice
case "$choice" in 
A|a) ls -l --color ;;
B|b) ps -f ;;
C|c) date ;;
D|d) who ;;
*) echo "Invalid choice"
esac
exit

