#!/bin/sh

if [ $# -eq 0 ]
then 
	echo "Usage: ${0#./} filelist"; exit 1
fi
for file in "$@"
do
	cp $file ${file}.bak
	echo "copy $file to $file.bak"
done
exit

